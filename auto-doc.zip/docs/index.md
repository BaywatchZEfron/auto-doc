# Bienvenido a AutoMaths

Esta documentación explica el uso de la librería de funciones matemáticas que acepta un número indefinido de argumentos (*args).

- Contiene operaciones de suma, resta, multiplicación y división.
- Todos los ejemplos se ejecutan en Python 3.x.

Para ver los ejemplos de uso y descripción de cada función, navega a la sección **Maths Functions**.

